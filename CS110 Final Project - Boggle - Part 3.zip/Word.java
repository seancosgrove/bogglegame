/**
* Sean Cosgrove
* CS 110B Project
* Boggle - Part 3
* Word Class
*/

// Import ArrayList class
import java.util.ArrayList;

/**
* Word class
* represents a word that was entered by a player
* stores the characters in the word as well as points earned
*/
public class Word {
   
   // instance variables
   private int score = 0; // the score of the player's word
   private String word = ""; // the String that will hold the player's word
   private int length; // the length of the player's word
   
   /**
   * default constructor
   * @param Tile ArrayList
   * iterates through ArrayList to determine word
   * takes length of word and determines points earned
   */
   public Word (ArrayList<Tile> tiles) {
      
      // iterate through ArrayList and build word String
      for (Tile i : tiles)
         word = word + i.toString();
      // get length of player's word
      length = word.length();
      // call determineScore method
      determineScore();
   
   }
   
   /**
   * determineScore method
   * @returns an int that represents the points earned
   * based on the length of the player's word
   */
   public int determineScore() {
   
      if (length < 3) // word length less than 3
         score = 0; // 0 points earned
      else if (length < 5) // word length is 3 or 4
         score = 1; // 1 point earned
      else if (length < 6) // word length is 5
         score = 2; // 2 points earned
      else if (length < 7) // word length is 6
         score = 3; // 3 points earned
      else if (length < 8) // word length is 7
         score = 5; // 5 points earned
      else // word length is more than 8
         score = 11; // 11 points earned
          
      return score; // return points earned
   
   }
   
   /**
   * getPoints method
   * @returns score of a word
   */
   public int getPoints() {
   
      return score;
   
   }
   
   /**
   * toString method
   * @Override
   */
   public String toString() {
   
      return word;  
          
   }
   
   /**
   * equals method
   * @Override
   */
   public boolean equals(Word other) {
   
      return (this.word == other.word);
   
   }

}