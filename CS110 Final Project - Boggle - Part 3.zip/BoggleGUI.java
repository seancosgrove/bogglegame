/**
* Sean Cosgrove
* CS 110B Project
* Boggle - Part 3
* BoggleGUI Class
*/

// Import java io and ArrayList classes
import java.io.*;
import java.util.ArrayList;

// Import javafx functions
// Application
import javafx.application.Application; 
import javafx.application.Platform;
// Stage and scene
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Node;
// Scene layouts
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
// Scene text and buttons
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
// Geometry methods
import javafx.geometry.Orientation;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
// Event handling
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;

/**
* BoggleGUI class
* represents the GUI of a Boggle game
* that utilizes many classes
*/
public class BoggleGUI extends Application {

   private Game game = new Game(); // the Game object that builds everything together
   private ArrayList<Tile> selectedTiles = new ArrayList<>(); // tiles that are selected
   private ArrayList<String> wordsList = new ArrayList<>(); // words scored on
   private Tile tile, lastTile; // the current Tile and the lastTile selected
   private int row; // the row of a Tile being clicked on
   private int column; // the column of a Tile being clicked on
   private boolean stop = false; // boolean to stop the game
   private GridPane grid;  // the board of Tile Panes
   private BorderPane pane;  // the primary layout for the application
   private VBox topBox, bottomBox; // the node to hold the user's score and words entered
   private Text status, title, words, score; // text for the status, title, words, and score
   private Button exitGame, newGame, testWord, clearSelected; // buttons to exit, make a new game, 
                                                              // test words, and clear selected Tile Panes
   /**
   * start method
   * @builds GUI and starts game
   */
   @Override
   public void start(Stage primaryStage) {
    
      pane = new BorderPane(); // the primary layout for the application
      grid = new GridPane(); // the board of Tile Panes
      Text letter; // the letter of a Tile
      drawBoard(); // call drawBoard method
      
      // Node for title and status updates
      topBox = new VBox(20.0);
      
      // Game title
      title = new Text("BOGGLE"); // Game title
      title.setFont(Font.font("Dialog BOLD",75)); // font and font size
      title.setUnderline(true); // underline
      topBox.setAlignment(Pos.CENTER); // set alignment to center
      topBox.setPrefSize(600,200); // set size of node
      topBox.setStyle("-fx-background-color:orange;"); // background color
      topBox.getChildren().add(title); // add text to node
      
      // Status updates
      status = new Text("Word Game"); // status update
      status.setFont(Font.font("Ariel Black",24)); // font and font size
      status.setLineSpacing(10.0); // line spacing
      topBox.getChildren().add(status); // add text to node
      
      // Node for user's score and words entered
      bottomBox = new VBox(20.0);
      
      // User's score
      score = new Text("Score: " + game.getScore()); // text of user's score
      score.setFont(Font.font("Ariel Black",24)); // font and font size
      bottomBox.setAlignment(Pos.CENTER); // set alignment to center
      bottomBox.setPrefSize(600,150); // set size of node
      bottomBox.setStyle("-fx-background-color:orange;"); // background color
      bottomBox.getChildren().add(score); // add text to node
      
      // Words entered
      words = new Text("Words: " + game.getWords()); // text of words scored on
      words.setFont(Font.font("Ariel Black",24)); // font and font size
      bottomBox.getChildren().add(words); // add text to node
      
      // Node for test word and clear selected button
      VBox leftBox = new VBox(20.0); 
            
      // Test a word button
      testWord = new Button("Test Word"); // initialize button with text
      testWord.setStyle("-fx-font: 24 arial-black; -fx-base: white;"); // font, font size, and color
      leftBox.setAlignment(Pos.CENTER); // set alignment to center
      leftBox.setPrefSize(300,600); // set size of node
      leftBox.setStyle("-fx-background-color:orange;"); // background color
      leftBox.getChildren().add(testWord); // add button to node
      // event handling when button is pressed
      testWord.setOnAction(new EventHandler<ActionEvent>() {
         public void handle(ActionEvent e) {
            try {
               // word is valid
               if (game.returnTest()) { // call returnTest method in Game
                  
                  wordsList = game.getWordsList(); // call getWordsList method from Game
                  selectedTiles = game.getSelectedTiles(); // call getSelectedTiles method from Game
                  Word word = new Word(selectedTiles); // create Word object from selectedTiles
                  
                  // word has not been scored on 
                  if (!wordsList.contains(word.toString().toLowerCase())) {
                  
                     game.testSelected(); // call testSelected method in Game
                     drawBoard(); // call drawBoard method
                     
                  }
                  // word has already been scored on
                  else if (wordsList.contains(word.toString().toLowerCase())) {
                  
                     statusReport(); // call statusReport method
                     status = new Text("You already scored point(s) with " + word.toString().toLowerCase()); // change status update text
                     status.setFont(Font.font("Ariel Black",24)); // font and font size
                     status.setLineSpacing(10.0); // line spacing
                     topBox.getChildren().add(status); // add text to node
                     game.clearSelected(); // call clearSelected method in Game
                     
                  }
                  
               } 
               // word is not valid
               else if (!game.returnTest()) {
               
                  selectedTiles = game.getSelectedTiles(); // call getSelectedTiles from Game
                  Word word = new Word(selectedTiles); // create Word object from selectedTiles
                  statusReport(); // call statusReport method
                  status = new Text("Sorry, " + word.toString().toLowerCase() + " is not a valid word."); // change status update text
                  status.setFont(Font.font("Ariel Black",24)); // font and font size
                  status.setLineSpacing(10.0); // line spacing
                  topBox.getChildren().add(status); // add text to node
                  game.clearSelected(); // call clearSelected method in Game
                  
               }   
            } catch (IOException error) {
               statusReport(); // call statusReport method
               status = new Text("An error occurred with your dictionary file"); // change status update text
               status.setFont(Font.font("Ariel Black",24)); // font and font size
               status.setLineSpacing(10.0); // line spacing
               topBox.getChildren().add(status); // add text to node
               game.clearSelected(); // call clearSelected method in Game
    
            }
         }
      });
      
      // Clear selected tiles button
      clearSelected = new Button("Clear Selected"); // initialize button with text
      clearSelected.setStyle("-fx-font: 24 arial-black; -fx-base: white;"); // font, font size, and color
      leftBox.getChildren().add(clearSelected); // add button to node
      // event handling when button is pressed
      clearSelected.setOnAction(new EventHandler<ActionEvent>() {
         public void handle(ActionEvent e) {
            game.clearSelected(); // call clearSelected method in Game
            statusReport(); // call statusReport method
            drawBoard(); // call drawBoard method
         }
      });
      
      // Node for new game and exit game button
      VBox rightBox = new VBox(20.0);
      
      // New game button
      newGame = new Button("New Game"); // initialize button with text
      newGame.setStyle("-fx-font: 24 arial-black; -fx-base: white;"); // font, font size, and color
      rightBox.setAlignment(Pos.CENTER); // set alignment to center
      rightBox.setPrefSize(300,600); // set size of node
      rightBox.setStyle("-fx-background-color:orange;"); // background color
      rightBox.getChildren().add(newGame); // add button to node
      // event handling when button is pressed
      newGame.setOnAction(new EventHandler<ActionEvent>() {
         public void handle(ActionEvent e) {
         
            bottomBox.getChildren().clear(); // clear bottomBox node
            
            game.resetScore(); // resets the score
            score = new Text("Score: " + game.getScore()); // text of user's score
            score.setFont(Font.font("Ariel Black",24)); // font and font size
            bottomBox.setAlignment(Pos.CENTER); // set alignment to center
            bottomBox.setPrefSize(600,150); // set size of node
            bottomBox.setStyle("-fx-background-color:orange;"); // background color
            bottomBox.getChildren().add(score); // add text to node
            
            game.resetWords(); // clear words scored
            words = new Text("Words: " + game.getWords()); // text of user's score
            words.setFont(Font.font("Ariel Black",24)); // font and font size
            bottomBox.setAlignment(Pos.CENTER); // set alignment to center
            bottomBox.setPrefSize(600,150); // set size of node
            bottomBox.setStyle("-fx-background-color:orange;"); // background color
            bottomBox.getChildren().add(words); // add text to node
      
            game = new Game(); // create new Game object
            statusReport(); // call statusReport method
            drawBoard(); // call drawBoard method
            
         }
       });
      
      // Exit game button
      exitGame = new Button("Exit Game"); // initialize button with text
      exitGame.setStyle("-fx-font: 24 arial-black; -fx-base: white;"); // font, font size, and color
      rightBox.getChildren().add(exitGame); // add button to node
      // event handling when button is pressed
      exitGame.setOnAction(new EventHandler<ActionEvent>() {
         public void handle(ActionEvent e) {
            System.exit(0); // terminate program
         }
       });
      
      pane.setCenter(grid); // set grid to center of primary layout pane
      pane.setBottom(bottomBox); // set wordsEntered node to bottom of primary layout pane
      pane.setTop(topBox); // set userScore node to top of primary layout pane
      pane.setLeft(leftBox); // set leftBox node to left of primary layout pane
      pane.setRight(rightBox); // set rightBox node to right of primary layout pane
      grid.setAlignment(Pos.CENTER); // set alignment to center 
      Scene scene = new Scene(pane); // create new scene with primary layout pane
      primaryStage.setScene(scene); // set primaryStage scene to new scene
      primaryStage.show(); // display primaryStage GUI
      
   }
   
   /**
   * drawBoard method
   * @creates board of TilePanes using information from the system
   */
   public void drawBoard() {
   
      ArrayList<Tile> selectedTiles = new ArrayList<>(); // ArrayList of Tiles to hold Tiles selected
      selectedTiles = game.getSelectedTiles(); // call getSelectedTiles method from Game
      int size = selectedTiles.size(); // the number of Tiles selected
      int lastIndex = size - 1; // the index number of the last Tile
      grid.getChildren().clear(); // clear the board
      
      // user has scored on at least one word
      if (game.getWords().length() > 1) {
      
         bottomBox.getChildren().clear(); // clear bottomBox node
         
         score = new Text("Score: " + game.getScore()); // set text with getScore method from Game
         score.setFont(Font.font("Ariel Black",24)); // font and font size
         bottomBox.setAlignment(Pos.CENTER); // set alignment to center
         bottomBox.setPrefSize(600,150); // set size
         bottomBox.setStyle("-fx-background-color:orange;"); // background color
         bottomBox.getChildren().add(score); // add text to node
         
         words = new Text("Words: " + game.getWords()); // set text with getWords method from Game 
         words.setFont(Font.font("Ariel Black",24)); // font and font size
         bottomBox.setAlignment(Pos.CENTER); // set alignment to center
         bottomBox.setPrefSize(600,150); // set size
         bottomBox.setStyle("-fx-background-color:orange;"); // background color
         bottomBox.getChildren().add(words); // add text to node
         statusReport(); // call statusReport method
         
      }
      // for each row
      for (int row = 0; row <= 3; row++) {
         // for each column
         for (int col = 0; col <= 3; col++) {  
         
            Tile tile = game.getTile(row, col); // create Tile with getTile method from Game
            TilePane tilePane = new TilePane(tile,row,col); // create TilePane object
            // Tile would be a valid move for the user
            if (game.isValidSelection(row,col))
               tilePane.setOnMouseClicked(this::tileClicked); // call tileClicked method when TilePane is clicked on
            // Tile would not be a valid move for the user
            else if (!game.isValidSelection(row,col)) 
               tilePane.setOnMouseClicked(this::invalidTileClicked); // call invalidTileClicked method when TilePane is clicked on
            // Tile has not been selected
            if (!game.getSelectedTiles().contains(tile)) {
               tilePane.setStyle("-fx-background-color:white;" // background color
                       +"-fx-border-width: 5;" // border
                       +"-fx-border-color: black;"); // border color
               grid.add(tilePane,col,row); // add TilePane to board
            }
            // Tile is the last Tile selected
            else if (game.getSelectedTiles().contains(tile) && tile.equals(selectedTiles.get(lastIndex))) {
               tilePane.setOnMouseClicked(this::tileClicked); // call tileClicked method when TilePane is clicked on
               tilePane.setStyle("-fx-background-color:blue;" // background color
                       +"-fx-border-width: 5;" // border
                       +"-fx-border-color: black;"); // border color
               grid.add(tilePane,col,row); // add TilePane to board
            }
            // Tile has been selected
            else if (game.getSelectedTiles().contains(tile)) {
               tilePane.setStyle("-fx-background-color:blue;" // background color
                       +"-fx-border-width: 5;" // border
                       +"-fx-border-color: black;"); // border color
               grid.add(tilePane,col,row); // add TilePane to board
            }
        
         }
         
      }
            
   }

   /**
   * statusReport method
   * @resets the topBox node in order to clear status updates
   */
   public void statusReport() {
   
      topBox.getChildren().clear(); // clear topBox node
      title = new Text("BOGGLE"); // Game title
      title.setFont(Font.font("Dialog BOLD",75)); // font and font size
      title.setUnderline(true); // underline
      topBox.setAlignment(Pos.CENTER); // set alignment to center
      topBox.setPrefSize(600,200); // set size of node
      topBox.setStyle("-fx-background-color:orange;"); // background color
      topBox.getChildren().add(title); // add text to node
      status = new Text("Word Game"); // Game title
      status.setFont(Font.font("Ariel Black",24)); // font and font size
      status.setLineSpacing(10.0); // line spacing
      topBox.getChildren().add(status); // add text to node
   
   }
       
   // event handler for user clicking on a valid TilePane
   public void tileClicked(MouseEvent click) {  
   
      TilePane pane = (TilePane)(click.getSource()); // get TilePane at source of mouse click
      tile = pane.getTile(); // call getTile method in TilePane
      int row = tile.getRow(); // call getRow method in Tile
      int col = tile.getColumn(); // call getColumn method in Tile
      boolean flag = tile.getSelected(); // call getSelected method in Tile
      ArrayList<Tile> selectedTiles = new ArrayList<>(); // create ArrayList of selected Tiles
      selectedTiles = game.getSelectedTiles(); // call getSelectedTiles method in Game
      int size = selectedTiles.size(); // the size of the selected Tiles ArrayList
      int lastIndex = size-1; // the last index will always be the size - 1      
      
      // Tile clicked on is selected
      if (selectedTiles.contains(this.tile)) {
      
         lastTile = selectedTiles.get(lastIndex); // get last Tile in selectedTiles ArrayList
         // Tile clicked on is the last tile selected
         if (selectedTiles.contains(this.tile) && this.tile.equals(this.lastTile)) {
         
            game.removeFromSelected(row, col); // call removeFromSelected method from Game
            statusReport(); // call statusReport method
            drawBoard(); // call drawBoard method
            
         }
         // Tile clicked on has already been selected
         else if (selectedTiles.contains(this.tile)) {
         
            statusReport(); // call statusReport method
            status = new Text("Tile has already been selected"); // change status update text
            status.setFont(Font.font("Ariel Black",24)); // font and font size
            status.setLineSpacing(10.0); // line spacing
            topBox.getChildren().add(status); // add text to node  
            
         }
         
      }
      // Tile clicked on is not selected   
      else if (!game.getSelectedTiles().contains(this.tile)) {
      
         game.addToSelected(row,col); // call addToSelected method from Game
         this.lastTile = this.tile; // set the last Tile equal to tile clicked on
         statusReport(); // call statusReport method
         drawBoard(); // call drawBoard method
         
      }
      
   }
   
   // event handler for user clicking on an invalid TilePane
   public void invalidTileClicked(MouseEvent click) {
   
      statusReport(); // call statusReport method
      status = new Text("Try a Tile adjacent to your last selection."); // status update
      status.setFont(Font.font("Ariel Black",24)); // font and font size
      status.setLineSpacing(10.0); // line spacing
      topBox.getChildren().add(status); // add text to node
   
   }
   
   /**
   * main method
   * @launches the GUI as an application
   */
   public static void main(String [] args) {
      launch(args);
   }

}