/**
* Sean Cosgrove
* CS 110B Project
* Boggle - Part 3
* Dictionary Class
*/

// Import Scanner class, ArrayList class, and io classes
import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;

/**
* Dictionary class
* creates an array of Strings containing the words of a dictionary
* contains a method that determines if a given word is in the dictionary
*/
public class Dictionary {

   // class ArrayList declaration
   private static ArrayList<String> dictionary; // the ArrayList to hold the dictionary words

   /**
   * default constructor
   * initializes the dictionary ArrayList
   * and calls the scanFile method
   */
   public Dictionary(String filename) throws IOException {
   
      try {
         // Initialize ArrayList object
         dictionary = new ArrayList<>();
         // Call scanFile method
         scanFile(dictionary, filename);
      } catch (IOException error) {
         System.out.println("File not found");
      }
         
   }
   
   /**
   * scanFile method
   * scans a given file and adds each line to dictionary ArrayList
   */
   public void scanFile(ArrayList<String> dictionary, String filename) throws IOException {
   
      // Create Scanner object
      Scanner scan = new Scanner(new File(filename));
      
      // Scan file
      while (scan.hasNext()) {
         
         // Scan each line and add word to dictionary ArrayList
         String word = scan.nextLine();
         dictionary.add(word);
      
      }
      
      // Close scanner
      scan.close();
   
   }
   
   /**
   * isValidWord method
   * @returns a boolean that determines whether the String created
   * by each selected Tile is a word in the dictionary ArrayList
   */
   public boolean isValidWord(ArrayList<Tile> tiles) {
      
      // Initialize empty String
      String word = "";
      
      // Iterate through Tile ArrayList
      for (Tile i : tiles) {
      
         // Combine tiles into a String
         word = word + i.toString();
      
      }
      
      // Return true when the dictionary ArrayList contains the word created
      if (dictionary.contains(word.toLowerCase()))
         return true;
      else
         return false;
   
   } 
   
}