/**
* Sean Cosgrove
* CS 110B Project
* Boggle - Part 3
* Board Class
*/

// Import Random, Arrays, and ArrayList classes
import java.util.Random;
import java.util.Arrays;
import java.util.ArrayList;

/**
* Board class
* creates an ArrayList of an Tile ArrayLists
* builds a Boggle board set up
*/
public class Board {

   // class Random object
   private static Random rand = new Random();
   
   // instance variables
   private ArrayList<Tile> tileRow1 = new ArrayList<>(4); // Tile ArrayList for the first row
   private ArrayList<Tile> tileRow2 = new ArrayList<>(4); // Tile ArrayList for the second row
   private ArrayList<Tile> tileRow3 = new ArrayList<>(4); // Tile ArrayList for the third row
   private ArrayList<Tile> tileRow4 = new ArrayList<>(4); // Tile ArrayList for the fourth row
   private ArrayList<ArrayList> gameBoard = new ArrayList<>(4); // ArrayList of the row ArrayLists for the gameboard
   
   // every letter die represented as an array
   final private String [] die0 = {"R", "I", "F", "O", "B", "X"};
   final private String [] die1 = {"I", "F", "E", "H", "E", "Y"};
   final private String [] die2 = {"D", "E", "N", "O", "W", "S"};
   final private String [] die3 = {"U", "T", "O", "K", "N", "D"};
   final private String [] die4 = {"H", "M", "S", "R", "A", "O"};
   final private String [] die5 = {"L", "U", "P", "E", "T", "S"};
   final private String [] die6 = {"A", "C", "I", "T", "O", "A"};
   final private String [] die7 = {"Y", "L", "G", "K", "U", "E"};
   final private String [] die8 = {"Qu", "B", "M", "J", "O", "A"};
   final private String [] die9 = {"E", "H", "I", "S", "P", "N"};
   final private String [] die10 = {"V", "E", "T", "I", "G", "N"};
   final private String [] die11 = {"B", "A", "L", "I", "Y", "T"};
   final private String [] die12 = {"E", "Z", "A", "V", "N", "D"};
   final private String [] die13 = {"R", "A", "L", "E", "S", "C"};
   final private String [] die14 = {"U", "W", "I", "L", "R", "G"};
   final private String [] die15 = {"P", "A", "C", "E", "M", "D"};

   /**
   * default constructor
   * builds Boggle board set up
   * calls getRow methods
   */
   public Board() {
      
      gameBoard.add(buildRow1());
      gameBoard.add(buildRow2());
      gameBoard.add(buildRow3());
      gameBoard.add(buildRow4());
     
   }
   
   /**
   * toString method
   * @Override
   */
   public String toString() {
   
      String board = ""; // String to return board set up

      // iterate through tileRow1 ArrayList
      for (Tile i : tileRow1) 
            board = board + i.toString() + "\t"; // add letter to String and tab
      board = board + "\n"; // start new line after row is added to String
      
      // iterate through tileRow2 ArrayList
      for (Tile i : tileRow2)
            board = board + i.toString() + "\t"; // add letter to String and tab
      board = board + "\n"; // start new line after row is added to String
      
      // iterate through tileRow3 ArrayList
      for (Tile i : tileRow3)
            board = board + i.toString() + "\t"; // add letter to String and tab
      board = board + "\n"; // start new line after row is added to String
      
      // iterate through tileRow4 ArrayList
      for (Tile i : tileRow4)
            board = board + i.toString() + "\t"; // add letter to String and tab

      // return board String
      return board;
   
   }
   
   /**
   * buildRow1 method
   * @returns an ArrayList of Tile objects that
   * represents each tile in the first row
   */
   public ArrayList<Tile> buildRow1() {
   
      String newTile; // local String variable to hold tile's letter
      
      newTile = getTile(); // call getTile method
      Tile t00 = new Tile(newTile, 0 , 0); // create new Tile object
      tileRow1.add(t00); // add tile to tileRow1 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t01 = new Tile(newTile, 0 , 1); // create new Tile object
      tileRow1.add(t01); // add tile to tileRow1 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t02 = new Tile(newTile, 0 , 2); // create new Tile object
      tileRow1.add(t02); // add tile to tileRow1 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t03 = new Tile(newTile, 0 , 3); // create new Tile object
      tileRow1.add(t03); // add tile to tileRow1 ArrayList
      
      return tileRow1; // return tileRow1 ArrayList
      
   }
   
   /**
   * buildRow2 method
   * @returns an ArrayList of Tile objects that
   * represents each tile in the second row
   */
   public ArrayList<Tile> buildRow2() {
   
      String newTile; // local String variable to hold tile's letter
      
      newTile = getTile(); // call getTile method
      Tile t10 = new Tile(newTile, 1 , 0); // create new Tile object
      tileRow2.add(t10); // add tile to tileRow2 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t11 = new Tile(newTile, 1 , 1); // create new Tile object
      tileRow2.add(t11); // add tile to tileRow2 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t12 = new Tile(newTile, 1 , 2); // create new Tile object
      tileRow2.add(t12); // add tile to tileRow2 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t13 = new Tile(newTile, 1 , 3); // create new Tile object
      tileRow2.add(t13); // add tile to tileRow2 ArrayList
      
      return tileRow2; // return tileRow2 ArrayList
      
   }
   
   /**
   * buildRow3 method
   * @returns an ArrayList of Tile objects that
   * represents each tile in the third row
   */
   public ArrayList<Tile> buildRow3() {
   
      String newTile; // local String variable to hold tile's letter
      
      newTile = getTile(); // call getTile method
      Tile t20 = new Tile(newTile, 2 , 0); // create new Tile object
      tileRow3.add(t20); // add tile to tileRow3 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t21 = new Tile(newTile, 2 , 1); // create new Tile object
      tileRow3.add(t21); // add tile to tileRow3 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t22 = new Tile(newTile, 2 , 2); // create new Tile object
      tileRow3.add(t22); // add tile to tileRow3 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t23 = new Tile(newTile, 2 , 3); // create new Tile object
      tileRow3.add(t23); // add tile to tileRow3 ArrayList
      
      return tileRow3; // return tileRow3 ArrayList
      
   }
   
   /**
   * buildRow4 method
   * @returns an ArrayList of Tile objects that
   * represents each tile in the fourth row
   */
   public ArrayList<Tile> buildRow4() {
   
      String newTile; // local String variable to hold tile's letter
      
      newTile = getTile(); // call getTile method
      Tile t30 = new Tile(newTile, 3 , 0); // create new Tile object
      tileRow4.add(t30); // add tile to tileRow4 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t31 = new Tile(newTile, 3 , 1); // create new Tile object
      tileRow4.add(t31); // add tile to tileRow4 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t32 = new Tile(newTile, 3 , 2); // create new Tile object
      tileRow4.add(t32); // add tile to tileRow4 ArrayList
      
      newTile = getTile(); // call getTile method
      Tile t33 = new Tile(newTile, 3 , 3); // create new Tile object
      tileRow4.add(t33); // add tile to tileRow4 ArrayList
      
      return tileRow4; // return tileRow4 ArrayList
      
   }
   
   /**
   * getRow1 method
   * @returns the first row of tiles
   */
   public ArrayList<Tile> getRow1() {
   
      return tileRow1;
   
   }
   
   /**
   * getRow2 method
   * @returns the first row of tiles
   */
   public ArrayList<Tile> getRow2() {
   
      return tileRow2;
   
   }
   
   /**
   * getRow3 method
   * @returns the first row of tiles
   */
   public ArrayList<Tile> getRow3() {
   
      return tileRow3;
   
   }
   
   /**
   * getRow4 method
   * @returns the first row of tiles
   */
   public ArrayList<Tile> getRow4() {
   
      return tileRow4;
   
   }
   
    /**
    * getTile method
    * @returns a String that represents the letter of a tile
    * picks a random die and rolls it to get a letter
    */
   public String getTile() {
   
      // initialize local variables
      String tileLetter = ""; // the letter(s) of a tile
      int dieNumber = rand.nextInt(15); // the random die picked for a tile
      int dieIndex = rand.nextInt(6); // the random value for the die
      
      if (dieNumber == 0) // die0 is randomly selected
         tileLetter = die0[dieIndex]; // set String to random die0 Array element
      else if (dieNumber == 1) // die1 is randomly selected
         tileLetter = die1[dieIndex]; // set String to random die1 Array element
      else if (dieNumber == 2) // die2 is randomly selected
         tileLetter = die2[dieIndex]; // set String to random die2 Array element
      else if (dieNumber == 3) // die3 is randomly selected
         tileLetter = die3[dieIndex]; // set String to random die3 Array element
      else if (dieNumber == 4) // die4 is randomly selected
         tileLetter = die4[dieIndex]; // set String to random die4 Array element
      else if (dieNumber == 5) // die5 is randomly selected
         tileLetter = die5[dieIndex]; // set String to random die5 Array element
      else if (dieNumber == 6) // die6 is randomly selected
         tileLetter = die6[dieIndex]; // set String to random die6 Array element
      else if (dieNumber == 7) // die7 is randomly selected
         tileLetter = die7[dieIndex]; // set String to random die7 Array element
      else if (dieNumber == 8) // die8 is randomly selected
         tileLetter = die8[dieIndex]; // set String to random die8 Array element
      else if (dieNumber == 9) // die9 is randomly selected
         tileLetter = die9[dieIndex]; // set String to random die9 Array element   
      else if (dieNumber == 10) // die10 is randomly selected
         tileLetter = die10[dieIndex];  // set String to random die10 Array element
      else if (dieNumber == 11) // die11 is randomly selected
         tileLetter = die11[dieIndex]; // set String to random die11 Array element
      else if (dieNumber == 12) // die12 is randomly selected
         tileLetter = die12[dieIndex]; // set String to random die12 Array element
      else if (dieNumber == 13) // die13 is randomly selected
         tileLetter = die13[dieIndex]; // set String to random die13 Array element
      else if (dieNumber == 14) // die14 is randomly selected
         tileLetter = die14[dieIndex]; // set String to random die14 Array element
      else if (dieNumber == 15) // die15 is randomly selected
         tileLetter = die15[dieIndex];  // set String to random die15 Array element
         
      return tileLetter; // return random letter String
   
   }

}