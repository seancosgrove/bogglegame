/**
* Sean Cosgrove
* CS 110B Project
* Boggle - Part 3
* Game Class
*/

// Import java.io and ArrayList classes
import java.io.*;
import java.util.ArrayList;

/**
* Game class
* represents a game of Boggle that
* utilizies multiple class objects
*/
public class Game {

   // instance variables
   private Board board; // the Board of Tiles
   private Word word; // the Word made by a set of Tiles
   private Dictionary dict; // the Dictionary object to verify words
   private int score = 0; // the player's score
   private int moves = 0; // the player's move per word
   private ArrayList<String> letters = new ArrayList<>(); // the letters of the tiles being selected
   private ArrayList<String> words = new ArrayList<>(); // the completed words that earn points
   private ArrayList<Tile> selectedTiles = new ArrayList<>(); // the tiles being selected
   private ArrayList<Tile> row1 = new ArrayList<>(); // the first row of tiles 
   private ArrayList<Tile> row2 = new ArrayList<>(); // the second row of tiles
   private ArrayList<Tile> row3 = new ArrayList<>(); // the third row of tiles
   private ArrayList<Tile> row4 = new ArrayList<>(); // the fourth tow of tiles
   private ArrayList<TilePane> selectedTilePanes = new ArrayList<>(); // the tile panes selected in the GUI
   
   /**
   * default constructor
   * @creates a Game object with a board of tiles 
   * and saves each row from the board into lists
   */
   public Game() {
         
      board = new Board(); // Initialize board object
      row1 = board.getRow1(); // call getRow1 method and save into row1 ArrayList
      row2 = board.getRow2(); // call getRow2 method and save into row2 ArrayList
      row3 = board.getRow3(); // call getRow3 method and save into row3 ArrayList
      row4 = board.getRow4(); // call getRow4 method and save into row4 ArrayList
        
   }

   /**
   * addToSelected method
   * @adds a tile to the selected tiles ArrayList and
   * turns the Tile's selection flag on
   */
   public void addToSelected(int row, int column) {
   
      // for each column
      for (int i = 0; i < 4; i++) { 
   
         if (column == i) {
            
            if (row == 0) {
               
               Tile selectedTile = row1.get(i); // get (0, i) Tile
               selectedTiles.add(selectedTile); // add to selected Tiles ArrayList
               selectedTile.selectTile(); // call selectTile method; sets Tile boolean to true
               letters.add(selectedTile.toString()); // add letter of Tile to letters array
               moves++; // add to moves counter
                
            } else if (row == 1) {
               
               Tile selectedTile = row2.get(i); // get (1, i) Tile
               selectedTiles.add(selectedTile); // add to selected Tiles ArrayList
               selectedTile.selectTile(); // call selectTile method; sets Tile boolean to true
               letters.add(selectedTile.toString()); // add letter of Tile to letters array
               moves++; // add to moves counter
                
            } else if (row == 2) {
               
               Tile selectedTile = row3.get(i); // get (2, i) Tile
               selectedTiles.add(selectedTile); // add to selected Tiles ArrayList
               selectedTile.selectTile(); // call selectTile method; sets Tile boolean to true
               letters.add(selectedTile.toString()); // add letter of Tile to letters array
               moves++; // add to moves counter
                
            } else if (row == 3) {
               
               Tile selectedTile = row4.get(i); // get (3, i) Tile
               selectedTiles.add(selectedTile); // add to selected Tiles ArrayList
               selectedTile.selectTile(); // call selectTile method; sets Tile boolean to true
               letters.add(selectedTile.toString()); // add letter of Tile to letters array
               moves++; // add to moves counter
                
            }
         
         }

      }
      
   }
   
   /**
   * removeFromSelected method
   * @removes a tile to the selected tiles ArrayList and
   * turns the Tile's selection flag off
   */
   public void removeFromSelected(int row, int column) {
   
      // for each column
      for (int i = 0; i < 4; i++) { 
   
         if (column == i) {
            
            if (row == 0) {
               
               Tile selectedTile = row1.get(i); // get (0, i) Tile
               selectedTiles.remove(selectedTile); // remove from selected Tiles ArrayList
               selectedTile.deselectTile(); // call deselectTile method; sets Tile boolean to false
               letters.remove(selectedTile.toString()); // remove letter of Tile from letters array
               moves--; // remove from move counter in case they deselect first move
                
            } else if (row == 1) {
               
               Tile selectedTile = row2.get(i); // get (1, i) Tile
               selectedTiles.remove(selectedTile); // remove from selected Tiles ArrayList
               letters.remove(selectedTile.toString()); // remove letter of Tile from letters array
               moves--; // remove from move counter in case they deselect first move
                
            } else if (row == 2) {
               
               Tile selectedTile = row3.get(i); // get (2, i) Tile
               selectedTiles.remove(selectedTile); // remove from selected Tiles ArrayList
               letters.remove(selectedTile.toString()); // remove letter of Tile from letters array
               moves--; // remove from move counter in case they deselect first move
                
            } else if (row == 3) {
               
               Tile selectedTile = row4.get(i); // get (3, i) Tile
               selectedTiles.remove(selectedTile); // remove from selected Tiles ArrayList
               letters.remove(selectedTile.toString()); // remove letter of Tile from letters array
               moves--; // remove from move counter in case they deselect first move
                
            }
         
         }

      }
      
   }

   /**
   * getTile method
   * @returns a Tile given a row and column number
   */
   public Tile getTile(int row, int column) {
   
      Tile checkTile; // local Tile object
   
      // for each column
      for (int i = 0; i < 4; i++) { 
   
         if (column == i) {
            
            if (row == 0) {
               
               checkTile = row1.get(i); // get (0, i) Tile
               return checkTile; // return Tile object
                
            } else if (row == 1) {
               
               checkTile = row2.get(i); // get (1, i) Tile
               return checkTile; // return Tile object
                
            } else if (row == 2) {
               
               checkTile = row3.get(i); // get (2, i) Tile
               return checkTile; // return Tile object
                
            } else if (row == 3) {
               
               checkTile = row4.get(i); // get (3, i) Tile
               return checkTile; // return Tile object
                
            }
         
         }

      }
      
      checkTile = new Tile("", row, column); // exception handling
      return checkTile; // return Tile object;
   
   }
   
   /**
   * getSelectedTiles method
   * @returns the ArrayList of selected Tiles
   */
   public ArrayList<Tile> getSelectedTiles() {
   
      return selectedTiles;
   
   }
   
   /**
   * clearSelected method
   * @clears the ArrayList of selected Tiles
   * and set moves counter to zero
   */
   public void clearSelected() {
   
      selectedTiles.clear();
      moves = 0;
   
   }
   
   /**
   * testSelected method
   * @verifies whether a group of selected Tiles
   * creates a valid word and adds points earned
   */
   public void testSelected() throws IOException {
   
      Word wordObj = new Word(selectedTiles); // create Word object out of selected Tiles to print
      dict = new Dictionary("dictionary.txt"); // initialize dictionary object
      boolean test = dict.isValidWord(selectedTiles); // call isValidWord method
      if (test == false)
         System.out.println("Sorry, " + wordObj + " is not a valid word.");
      else if (test == true) {
      
         word = new Word(selectedTiles); // initialize instance Word object
         score += word.getPoints(); // call getPoints method and add to score
         words.add(word.toString().toLowerCase()); // add word to words ArrayList
         clearSelected(); // call clearSelected method
      
      }
   
   }
   
   /**
   * returnTest method
   * @returns a boolean whether a group of 
   * selected Tiles creates a valid word
   */
   public boolean returnTest() throws IOException {
   
      Word wordObj = new Word(selectedTiles); // create Word object out of selected Tiles to print
      dict = new Dictionary("dictionary.txt"); // initialize dictionary object
      boolean test = dict.isValidWord(selectedTiles); // call isValidWord method
      if (test == false)
         return false;
      else
         return true;
   
   }
   
   /**
   * isValidSelection method
   * @verifies whether a selected tile is adjacent to
   * the previously selected tile or not
   */
   public boolean isValidSelection(int row, int column) {
   
      boolean valid = false; // initialize boolean variable to return
      if (moves == 0) // first Tile is being selected
         valid = true;
      else if (selectedTiles.size() >= 1) {
      
         Tile lastTile = selectedTiles.get(selectedTiles.size()-1); // create Tile object of the last Tile in the selectedTiles ArrayList
         int lastRow = lastTile.getRow(); // call getRow method
         int lastColumn = lastTile.getColumn(); // call getColumn method
         int rowBelow = lastRow + 1; // create int of the row below the last Tile
         int rowAbove = lastRow - 1; // create int of the row above the last Tile
         int columnRight = lastColumn + 1; // create int of the column to the right of the last Tile
         int columnLeft = lastColumn - 1; // create int of the column to the left of the last Tile
         
         if ((row == lastRow) && (column == lastColumn)) // tiles have the same coordinates
            valid = false;
         else if (((row == lastRow) || (row == rowBelow) || (row == rowAbove)) && // row is adjacent to last Tile's row
                 ((column == lastColumn) || (column == columnRight) || (column == columnLeft))) // column is adjacent to last Tile's column
            valid = true;
      
      }
      
      return valid; // return boolean variable
      
   }
   
   /**
   * getWordsList method
   * @returns the ArrayList of words
   */
   public ArrayList<String> getWordsList() {
   
      return words;
   
   }
   
   /**
   * getWords method
   * @returns the ArrayList of words scored as a String
   */
   public String getWords() {
   
      String wordsScored = ""; // initial return String
      // for each word in words ArrayList
      for (String i : this.words) {
         // add word to String
         wordsScored = wordsScored + i + ", ";
      
      }
      // return String of words
      return wordsScored;
   
   }
   
   /**
   * resetWords method
   * @resets the String of words
   */
   public void resetWords() {
   
      this.words.clear();
   
   }
   
   /**
   * getScore method
   * @returns the user's score
   */
   public int getScore() {
      
      return score;
   
   }
   
   /**
   * resetScore method
   * @resets the user's score
   */
   public void resetScore() {
      
      this.score = 0;
   
   }
   
   /**
   * toString method
   * @Override
   */
   public String toString() {
   
      String gameboard = "\n"; // initialize String variable with blank line
      gameboard = gameboard + board.toString() + "\n"; // add board of Tiles
      gameboard = gameboard + "Selected: " + selectedTiles + "\n"; // add selected Tiles list
      gameboard = gameboard + "Words: " + words + "\n"; // add words list
      gameboard = gameboard + "Score: " + score + "\n"; // add score int
      return gameboard; // return String variable
   
   }
   
}