/**
* Sean Cosgrove
* CS 110B Project
* Boggle - Part 3
* Tile Class
*/

/**
* Tile class
* represents a single tile in a game of Boggle
* contains an override for the toString() method
*/
public class Tile {

   // instance variables
   private char letter; // the letter of a tile
   private String letters = ""; // the letters of a tile
   private int row; // the row number of a tile
   private int column; // the column number of a tile
   private boolean selected; // tile has been selected or not
   
   /**
   * default constructor
   * represents a single tile with a letter, row number,
   * column number, and a flag if it is selected
   */
   public Tile(char letter, int row, int column) {
   
         this.letter = letter;
         this.row = row;
         this.column = column;
         this.selected = false;
   
   }
   
   /**
   * alternate constructor
   * represents a single tile with more than one letter, row number,
   * column number, and a flag if it is selected
   */
   public Tile(String letters, int row, int column) {
   
         this.letters = letters;
         this.row = row;
         this.column = column;
         this.selected = false;
   
   }  
   
   /**
   * getRow method
   * @returns the row number of a Tile object
   */
   public int getRow() {
   
      return row;
   
   }
   
   /**
   * getColumn method
   * @returns the column number of a Tile object
   */
   public int getColumn() {
   
      return column;
   
   }
   
   /**
   * getSelected method
   * @returns the selection flag value of a Tile object
   */
   public boolean getSelected() {
   
      return selected;
   
   }
   
   /**
   * selectTile method
   * @sets selected boolean to true
   */
   public void selectTile() {
   
      this.selected = true;
   
   }
   
   /**
   * deselectTile method
   * @sets selected boolean to false
   */
   public void deselectTile() {
   
      this.selected = false;
   
   }

   /**
   * toString method
   * @Override
   */
   public String toString() {
   
      if (letters.equals(null) || letters.equals("")) // letters String variable is empty
         return "" + letter; // return letter char
      else
         return "" + letters; // return letters String
   
   }
   
   /**
   * equals method
   * @Override
   */
   public boolean equals(Tile other) {
   
      return ((this.row == other.row) && (this.column == other.column));
   
   }
  
}