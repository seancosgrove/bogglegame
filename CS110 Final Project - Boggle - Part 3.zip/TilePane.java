/**
* Sean Cosgrove
* CS 110B Project
* Boggle - Part 3
* TilePane Class
*/

// Import javafx
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.geometry.Orientation;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;

/**
* TilePane class
* represents a single Tile Pane in the Boggle GUI
*/
public class TilePane extends HBox {

   // instance variables
   private Tile tile; // the tile that the pane represents
   private String letter; // the letter of the tile
   private int row; // the row of the tile
   private int col; // the column of the tile
   
   /**
   * default constructor
   * represents a single Tile Pane with a tile, row, and column
   */
   public TilePane(Tile tile, int row, int col) {
      
      this.tile = tile; // the Tile object associated with this pane
      this.row = row; // the row of the Tile
      this.col = col; // the column of the Tile
      this.letter = tile.toString(); // the letter of the Tile
      this.setAlignment(Pos.CENTER); // set alightment to center
      this.setPrefSize(150,150); // set size of Tile Pane
      this.setStyle("-fx-border-width: 5;" // border width
                       +"-fx-border-color: black;"); // border color
      Text t = new Text(letter); // create text of letter String
      t.setFont(Font.font("Ariel Black",100)); // font and size
      this.getChildren().add(t); // add to node
   
   }
   
   /**
   * getRow method
   * @returns the row of a Tile Pane
   */
   public int getRow() {
   
      return row;
   
   }
   
   /**
   * getColumn method
   * @returns the column of a Tile Pane
   */
   public int getColumn() {
      
      return col;
   
   }
   
   /**
   * getTile method
   * @returns the Tile of a Tile Pane
   */
   public Tile getTile() {
   
      return tile;
   
   }
   
   /**
   * equals method
   * @Override
   */
   public boolean equals(TilePane other) {
   
      return ((this.row == other.row) && (this.col == other.col));
   
   }

}
